
@extends('welcome')
@section('content')

      <div class="wrapper">
         <form class="form-signin" method="post" action="{{route('login')}}">
            {{csrf_field()}}
            @if(session('error'))
            <h3 class="alert alert-danger">{{session('error')}}</h3>
            @endif
            <h2 class="form-signin-heading">Please login</h2>
            </br>
            @if($errors->has('email'))
            <p>{{$errors->first('email')}}</p>
            @endif
            @if($errors->has('password'))
            <p>{{$errors->first('password')}}</p>
            @endif
            <lable>Email</lable>
            <input type="email" class="form-control" name="email" /></br>
            <label>PASSWORD</label>
            <input type="password" class="form-control" name="password" />  <br>
            <label class="checkbox"></br>
            <input type="checkbox" value="remember-me" id="rememberMe" name="rememberme"> Remember me</br>
            </label>
            <button class="btn btn-lg btn-primary btn-block" type="submit">LOGIN</button>
            <button class="btn btn-lg btn-primary btn-block"><a href="reset" style="color:white">FORGOTPASSWORD</a></button>
         </form>
      </div>
     


  

@endsection