@extends('layout.adminlayout')
@section('content')<!-- <html>
   <head>
   </head>
   <body> -->

      <div class="container">
         <h2>registration form</h2>
         <form class="form-horizontal" id="addproduct">
         {{csrf_field()}}
            <!-- <input type="hidden" name="_method" value="PUT">
             <input type="hidden" name="_token" value="{{ csrf_token() }}"> -->
          
            <div class="form-group">
               <label class="control-label col-sm-2" >ProductName</label>
               <div class="col-sm-10">
                  <input type="text" class="form-control" id="product_name"  name="product_name">
                  @if($errors->has('first_name'))
                  <p>{{$errors->first('first_name')}}</p>
                  @endif
               </div>
            </div>
            <div class="form-group">
               <label class="control-label col-sm-2" for="email">ProductSize:</label>
               <div class="col-sm-10">
                  <input type="text" class="form-control" id="product_size"  name="product_size">
                  @if($errors->has('email'))
                  <p>{{$errors->first('email')}}</p>
                  @endif
               </div>
            </div>
            
            <div class="form-group">
               <label class="control-label col-sm-2" for="pwd">ProductColor:</label>
               <div class="col-sm-10">
                  <input type="text" class="form-control" id="product_color"  name="product_color">
                  @if($errors->has('password'))
                  <p>{{$errors->first('password')}}</p>
                  @endif
               </div>
            </div>
            <div class="form-group">
               <label class="control-label col-sm-2" for="pwd">ProductQuantity:</label>
               <div class="col-sm-10">
                  <input type="number" class="form-control" id="product_qty"  name="product_qty">
                  @if($errors->has('password'))
                  <p>{{$errors->first('password')}}</p>
                  @endif
               </div>
            </div>
             <div class="form-group">
               <label class="control-label col-sm-2" >ProductPrice:</label>
               <div class="col-sm-10">
                  <input type="text" class="form-control" id="product_price"  name="product_price">
                  @if($errors->has('password'))
                  <p>{{$errors->first('password')}}</p>
                  @endif
               </div>
            </div>
            <div class="form-group">
               <label class="control-label col-sm-2" >ProductDetail:</label>
               <div class="col-sm-10">
                  <input type="text" class="form-control" id="product_detail"  name="product_detail">
                  @if($errors->has('password'))
                  <p>{{$errors->first('password')}}</p>
                  @endif
               </div>
            </div>
            <div class="form-group">
            <label class="control-label col-sm-2" >ProductImage:</label>
                     <div class="col-sm-6 col-md-4 col-xs-12">
                           <div class="signup-profile">
                            
                               <input type="file" class="updateprofile myprofileinfo" name="file" id="file">
                            </div>
                     </div>
            </div>

            <div class="form-group">
               <div class="col-sm-offset-2 col-sm-10">
                  <button type="submit" id="product" class="btn btn-default">Submit</button>
               </div>
            </div>
         </form>
      </div>

      <script src="{{asset('/public/assets/js/jquery-3.2.1.min.js')}}"></script>
   <script src="{{asset('/public/assets/bootstrap/bootstrap.min.js')}}"></script>
     <script src="{{asset('/public/assets/custom_js/register_product.js')}}"></script>
  
<!-- </body>
   </html> -->
@endsection