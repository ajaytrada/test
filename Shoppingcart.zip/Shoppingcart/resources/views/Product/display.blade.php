@extends('layout.layout')
@section('content')<!-- <html>
   <head>
   </head>
   <body> -->

      <div class="container">
      {{csrf_field()}}
      <h3>Product</h3>
      <div class="row">
      	@foreach($data as $a)
      	<div class="col-md-3">
      	  <div class="thumbnail" style="width:260px;">
            <img src="{{asset('storage/Image/WomenTshirts')}}/{{$a->product_image}}" style="height:200px;"/>
            <div> 
              <center>	
                  <p>{{$a->product_name}}</p>
                  <p>{{$a->product_details}}</p>
                  <p>{{$a->product_color}}</p>
                  <p>{{$a->product_size}}</p>
                  <p>Price:Rs.{{$a->product_price}}</p>
       		        <button class="btn btn-primary" id="cart" value="{{$a->id}}">ADD TO CART</button>
              </center>
            </div>
          </div>
        </div>
        @endforeach 
      </div>
      </div>
      
        

      <script src="{{asset('/public/assets/js/jquery-3.2.1.min.js')}}"></script>
   <script src="{{asset('/public/assets/bootstrap/bootstrap.min.js')}}"></script>
     <script src="{{asset('/public/assets/custom_js/register_product.js')}}"></script>
   @endsection
