<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/layout', function () {
    return view('layout.layout');
});



Route::get('/',function () {
    return view('welcome');
});

//display register products 
Route::get('/add', 'Product\RegisterController@register')->name('add');

//product save in database
Route::post("/addProduct","Product\RegisterController@postRegister")->name('addProduct');

//display product in webpage
Route::get("/displayProduct","Product\DisplayController@fetchProduct")->name('displayProduct');

//insert product to cart
Route::post("/addCart","Product\CartController@addCart")->name('addCart');

//update  cart products
Route::post("/updateCart","Product\CartController@updateCart")->name('updateCart');

//post update product value in cart
Route::post("/productupdateCart","Product\CartController@postupdateCart")->name('productupdateCart');

//remove product from cart

Route::post("/deleteCart","Product\CartController@deleteCart")->name('deleteCart');






Route::get("/showcart","Product\CartController@index")->name('showcart');

Route::get("/checkout","Product\CartController@checkout")->name('checkout');

Route::post("/paypal","Checkout\PaymentController@paywithpaypal")->name('paypal');
Route::get("/status","Checkout\AddMoneyController@getPaymentStatus")->name('status');
Route::post("/paypal1","Checkout\AddMoneyController@postPaymentWithpaypal")->name('paypal1');







		

