<?php

namespace App\Http\Controllers\Product;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Cart;
use App\Product;
use Session;

class CartController extends Controller
{
	//display cart items
    public function index()
    {
    	
    	$items = Cart::content(); 
    	$t=Cart::count();
    	
    	return view('cart.index',compact('items','t'));
    }

    //products add to cart
    public function addCart(Request $request)
    {
    	
    	$id=$request->id;
    	$token=$request->_token;
    	$product=Product::find($id);

    	if(cart::add(array('id'=>$product->id,'name'=>$product->product_name,'price'=>$product->product_price,'details'=>$product->product_detail,'color'=>$product->product_color,'size'=>$product->product_size,'price'=>$product->product_price,'qty'=>$product->product_qty)))
    	{
    		$n=cart::count();
    		return response()->json($n);
    	}
    	else
    	{
    		echo "can't add in count";
    	}
    	

    	
    }

    //update cart products
    public function updateCart(Request $request)
    {
    
			$id=$request->id;
			$rows=Cart::content();

			$rowId = $rows->where('id', $id)->first()->rowId;
			$m=cart::get($rowId);

			$n=json_encode($m);
				return response()->json([$n]);
	}

	//post update product
	public function postupdateCart(Request $request)
    {
    
			$i=$request->all();
			$id=$request->id;
			$name=$request->name;
			$price=$request->price;
			$qty=$request->qty;
			$rows=Cart::content();

			$rowId = $rows->where('id', $id)->first()->rowId;

			if(cart::update($rowId,['id'=>$id,'name'=>$name,'price'=>$price,'qty'=>$qty]))
			{
				
			}
			else
			{
				return response()->json("not success");
			}
	}

	//dremove product from cart
	public function deleteCart(Request $request)
    {
    		$id=$request->id;
			$rows=Cart::content();

			$rowId = $rows->where('id', $id)->first()->rowId;
			Cart::remove($rowId);
			return response()->json("success");


	}

	//display checkout form
	public function checkout()
	{
		return view('cart.checkout');
	}

}
