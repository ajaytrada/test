<?php

namespace App\Http\Controllers\Product;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Product;

class RegisterController extends Controller
{
   public function register()
   {

   		return view('Product.add');
   }

   

   public function postRegister(Request $request)
   {
   			$Products = new Product;
   			$Products->product_name=$request->product_name;
   			$Products->product_price=$request->product_price;
    		$Products->product_color=$request->product_color;
    		$Products->product_size=$request->product_size;
    		$Products->product_detail=$request->product_detail;
    		$Products->product_qty=$request->product_qty;

    		
   		 if($file=$request->file('image'))
     	{
           $name=$file->getClientOriginalName();
            $extension= $file->getClientOriginalExtension();
            if($extension=='jpg'||$extension=='jpeg'||$extension=='gif'||$extension=='png')
            {
                 if($file->move('storage/Image/WomenTshirts',$name))
                 {
                    $Products->product_image=$name;
                    if($Products->save())
                    {
                    	return response()->json(['Product submied']);
                    }
                    else
                    {
                    	return response()->json(['Product  not submied']);
                    }
                 }
                 else
                 {
                     return response()->json(['error in edit']);
                 }
              
            }
            else
            {
                 return response()->json(['Please uploade valid extension file']);
            }

        }
        	if($Products->save())
    		{
    			print_r($Products);
        		exit;
        	}
        	else
        	{
        		echo "no";
        		exit;
        	}
   }
}
