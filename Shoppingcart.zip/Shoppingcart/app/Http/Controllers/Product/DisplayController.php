<?php

namespace App\Http\Controllers\Product;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Product;
use Cart;

class DisplayController extends Controller
{
	public function fetchProduct()
	{
	    $data=Product::all();
	    $t=cart::count();
	    return view('Product.display',compact('data','t'));
	}
	  
}
