<?php
namespace App\Http\Controllers;
Use Sentinel;
use App\Http\Requests\validation_login;
use App\Http\Controllers\Auth;
use Illuminate\Http\Request;

class LoginController extends Controller
{
    public function login()
	{
		return View('user.login');
	}

	public function postlogin(request $request)
	{
	$this->validate($request,validation_login::rules());     
		if(Sentinel::authenticate($request->all())) 
		{  

			echo "hii";
			// if (Sentinel::getUser()->inRole('admin') == TRUE)
   //    			return redirect('ManagerRegister');
   //      	else if (Sentinel::getUser()->inRole('users') )
   //      	 	return redirect('user1');
   //      	else if (Sentinel::getUser()->inRole('manager'))
   //      	 	return redirect('manager');
        } 
		else
			return redirect()->back()->with('error','email or Password incorrect.');

	}
	public function logout(Request $request)
	{
		Sentinel::logout();
		return view('welcome');
	}
}

