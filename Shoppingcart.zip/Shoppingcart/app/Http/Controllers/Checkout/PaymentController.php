<?php

namespace App\Http\Controllers\Checkout;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use PayPal\Api\Amount; 
use PayPal\Api\Details; 
use PayPal\Api\Item; 
use PayPal\Api\ItemList; 
use PayPal\Api\Payer; 
use PayPal\Api\Payment; 
use PayPal\Api\RedirectUrls; 
use PayPal\Api\Transaction;
use PayPal\Auth\OAuthTokenCredential;
use PayPal\Rest\ApiContext;
use PayPal\Api\ExecutePayment;


class PaymentController extends Controller
{
	private $_api_context;
    public function __construct()
    {
    	$paypal_conf = \Config::get("paypal");
    	$this->_api_context=new ApiContext(new OAuthTokenCredential(
    		$paypal_conf['client_id'],
    		$paypal_conf['secret']
    		));
    	$this->_api_context->setConfig($paypal_conf['settings']);
    	
    }

    public function paywithpaypal()
    {
    		
		    $payer = new Payer();
			$payer->setPaymentMethod("paypal");

			$item1 = new Item();
			$item1->setName('Ground Coffee 40 oz')
			    ->setCurrency('USD')
			    ->setQuantity(1)
			    ->setSku("123123") // Similar to `item_number` in Classic API
			    ->setPrice(7.5);
			$item2 = new Item();
			$item2->setName('Granola bars')
			    ->setCurrency('USD')
			    ->setQuantity(5)
			    ->setSku("321321") // Similar to `item_number` in Classic API
			    ->setPrice(2);

			$itemList = new ItemList();
			$itemList->setItems(array($item1));


			$details = new Details();
			$details->setShipping(1.2)
			    ->setTax(1.3)
			    ->setSubtotal(17.50);

			$amount = new Amount();
			$amount->setCurrency("USD")
			    ->setTotal(20)
			    ->setDetails($details);

			$transaction = new Transaction();
			$transaction->setAmount($amount)
			    ->setItemList($itemList)
			    ->setDescription("Payment description")
			    ->setInvoiceNumber(uniqid());


			$redirectUrls = new RedirectUrls();
			$redirectUrls->setReturnUrl('http://mayuri.com/Shoppingcart/status')
			    ->setCancelUrl('http://mayuri.com/Shoppingcart/status');

			$payment = new Payment();
			$payment->setIntent("sale")
			    ->setPayer($payer)
			    ->setRedirectUrls($redirectUrls)
			    ->setTransactions(array($transaction));

			    $paypal_conf = \Config::get("paypal");
			  $this->_api_context=new \Paypal\Rest\ApiContext(
   			 new \PayPal\Auth\OAuthTokenCredential(
        		$paypal_conf['client_id'],
    			$paypal_conf['secret']
        		
   				 ));
			 $this->_api_context->setConfig($paypal_conf['settings']);

			$request = clone $payment;

			try {
				//$payment=$_GET['paymentId'];
				
			    ///$payment->create($this->_api_context);
			     $payment->create($this->_api_context);
	            

			} 
			catch (\PayPal\Exception\PPConnectionException $ex)
			{
			    if(\Config::get('app.debug'))
			    {
			    	\Session::put('error',"connection timeout");
			    		return redirect()->route('/');
			    }
			    else
			    {
			    	\Session::put('error',"some error  occure,sorry for inconvenient");
			    	return redirect()->route('/');
			    }
			}
			$allLinks = $payment->getLinks();
			print_r($allLinks);
			exit;
			foreach($payment->getLinks() as $links){

				if($link->getRel() == 'approval_url')
				{
					$redirect_url = $link->getHref();
					break;
				}
			}

			Session::put('paypal_payment_id',$payment->getId());

			if(isset($redirect_url))
			{
				return Redirect::array($redirect_url);
			}

			\Session::put('error','unknown error occured');
			return redirect::to('/');

	}
}


