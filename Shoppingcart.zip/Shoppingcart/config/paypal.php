<?php
return [
'client_id'=>'AcH94SNgpSZgQfY5-SrYcEaJrixdgvTyYBiqGaGW1dFjyHFtvnC5XIgGPjTvMsoV86sYFasoy0tZaktM',
'secret'=>'EEeA1L_q6K8xnBSn8VhvkT6c1fEr_gKOu3EoiXb-IsZHsw8WiQtwWuR95t_hpFtw5ytVy-QOJpxdHw2b',
'settings'=>array(
	'mode'=>'sandbox',
	'http_connectionTimeout'=>30,
	'log.logEnabled'=>true,
	'log.FileName'=>storage_path().'/logs/paypal/log',
	'log.Loglevel'=>'Error'
	) ];