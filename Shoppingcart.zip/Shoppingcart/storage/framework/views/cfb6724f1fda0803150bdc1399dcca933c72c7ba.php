<?php $__env->startSection('content'); ?><!-- <html>
   <head>
   </head>
   <body> -->

      <div class="container">
      <?php echo e(csrf_field()); ?>

      <h3>Product</h3>
      <div class="row">
      	<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      	<div class="col-md-3">
      	  <div class="thumbnail" style="width:260px;">
            <img src="<?php echo e(asset('storage/Image/WomenTshirts')); ?>/<?php echo e($a->product_image); ?>" style="height:200px;"/>
            <div> 
              <center>	
                  <p><?php echo e($a->product_name); ?></p>
                  <p><?php echo e($a->product_details); ?></p>
                  <p><?php echo e($a->product_color); ?></p>
                  <p><?php echo e($a->product_size); ?></p>
                  <p>Price:Rs.<?php echo e($a->product_price); ?></p>
       		        <button class="btn btn-primary" id="cart" value="<?php echo e($a->id); ?>">ADD TO CART</button>
              </center>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
      </div>
      </div>
      
        

      <script src="<?php echo e(asset('/public/assets/js/jquery-3.2.1.min.js')); ?>"></script>
   <script src="<?php echo e(asset('/public/assets/bootstrap/bootstrap.min.js')); ?>"></script>
     <script src="<?php echo e(asset('/public/assets/custom_js/register_product.js')); ?>"></script>
   <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>