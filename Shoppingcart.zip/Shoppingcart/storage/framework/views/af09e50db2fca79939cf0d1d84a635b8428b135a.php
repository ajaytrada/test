<?php $__env->startSection('content'); ?><!-- <html>
   <head>
   </head>
   <body> -->

      <div class="container">
         <h2>registration form</h2>
         <form class="form-horizontal" action="<?php echo e(route('register')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <input type="hidden"  value="<?php echo e(csrf_token()); ?>"  />
            <div class="form-group">
               <label class="control-label col-sm-2" for="email">Firstname</label>
               <div class="col-sm-10">
                  <input type="text" class="form-control" id="frst" placeholder="Enter frstname" name="first_name">
                  <?php if($errors->has('first_name')): ?>
                  <p><?php echo e($errors->first('first_name')); ?></p>
                  <?php endif; ?>
               </div>
            </div>
            <!-- <div class="form-group">
               <label class="control-label col-sm-2" for="email">Lastname:</label>
               <div class="col-sm-10">
                  <input type="text" class="form-control" id="lst" placeholder="Enter lastname" name="last_name">
                  <?php if($errors->has('last_name')): ?>
                  <p><?php echo e($errors->first('last_name')); ?></p>
                  <?php endif; ?>
               </div> 
            </div>-->
            <div class="form-group">
               <label class="control-label col-sm-2" for="email">Email:</label>
               <div class="col-sm-10">
                  <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
                  <?php if($errors->has('email')): ?>
                  <p><?php echo e($errors->first('email')); ?></p>
                  <?php endif; ?>
               </div>
            </div>
            
            <div class="form-group">
               <label class="control-label col-sm-2" for="pwd">Password:</label>
               <div class="col-sm-10">
                  <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="password">
                  <?php if($errors->has('password')): ?>
                  <p><?php echo e($errors->first('password')); ?></p>
                  <?php endif; ?>
               </div>
            </div>
            <!--   <div class="form-group">
               <label class="control-label col-sm-2" for="pwd">lastlogin:</label>
               <div class="col-sm-10">          
                 <input type="text" class="form-control" id="pwd" placeholder="Enter password" name="log">
               </div>
               </div> -->
            <!-- <div class="form-group">        
               <div class="col-sm-offset-2 col-sm-10">
                 <div class="checkbox">
                   <label><input type="checkbox" name="remember"> Remember me</label>
                 </div>
               </div>
               </div> -->
            <div class="form-group">
               <div class="col-sm-offset-2 col-sm-10">
                  <button type="submit" class="btn btn-default">Submit</button>
               </div>
            </div>
         </form>
      </div>
   </body>
</html>
<!-- </body>
   </html> -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>