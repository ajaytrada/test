<!-- navbar start -->

<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="<?php echo e(asset('/public/css/bootstrap.css')); ?>">
     
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
   

  <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
  <![endif]-->

</head>

<body>
<nav class="navbar" >

  <div class="container-fluid">

    <div class="navbar-header">
      <h3 style="color:lightblue;">Myntra</h3>

      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#KallableNavbar">

        <span class="icon-bar"></span>

        <span class="icon-bar"></span>

        <span class="icon-bar"></span>

      </button>

      <a class="navbar-brand" href="index.html">

        <img src="<?php echo e(asset('/public/assets/images/logo.png')); ?>" alt="" />

      </a>

    </div>

    <div class="collapse navbar-collapse" >

      <ul class="nav navbar-nav">

        <li>

          <a href="<?php echo e(route('displayProduct')); ?>">Products</a>

        </li>

        <li>

          <a href="<?php echo e(route('add')); ?>">Home</a>

        </li>

        <li>

          <a href="use-cases.html">Login</a>

        </li>

        <li>

          <a href="enterprise.html">Register</a>

        </li>

      </ul>

      

      <ul class="nav navbar-nav navbar-right">
       
    <ul class="navbar-right">
       
     <a href="<?php echo e(route('showcart')); ?>"  style='font-size:20px;'><i class="fa fa-shopping-cart"></i>
      <span class="badge badge-pill badge-warning">
      <div class="cartcount"><?php echo e($t); ?></div>

      </span>

       
      <?php if($t>0): ?>
      view cart
       <?php else: ?>
       <div class="d" style="display: none">cart</div>
       <?php endif; ?>
    
       </a>
        </ul> <!--end navbar-right -->
        </li>

      </ul>

    </div>

  </div>

</nav>
<?php echo $__env->yieldContent('content'); ?>
<div class="footer">
  <div class="container">
    <div class="row">
      <div class="col-sm-4 col-md-3 col-xs-12">
        <div class="footer-box">
          <h4>Connect with Us</h4>
          <div class="contact-row">
            <i class="fa fa-envelope-o" aria-hidden="true"></i>
            <span>Email : hello@kallable.com</span>
          </div>
          <div class="contact-row">
            <img src="<?php echo e(asset('/public/assets/images/footer-canada-icon.png')); ?>" alt="" />
            <span>Canada : +1 416 4074989</span>
          </div>
          <div class="contact-row">
            <img src="./public/assets/images/footer-singapore-icon.png" alt="" />
            <span>Singapore : +65 97281978</span>
          </div>
        </div>
      </div>
      <div class="col-sm-3 col-md-2 col-xs-12">
        <div class="footer-box">
          <h4>Links</h4>
          <ul class="list-unstyled">
            <li>
              <a href="pricing.html">Pricing</a>
            </li>
            <li>
              <a href="how-it-works.html">How it Works </a>
            </li>
            <li>
              <a href="use-cases.html">Use Cases </a>
            </li>
            <li>
              <a href="enterprise.html">Enterprise </a>
            </li>
            <li>
              <a href="about-us.html">About Us</a>
            </li>
            <li>
              <a href="#">Sign in</a>
            </li>
          </ul>
        </div>
      </div>
      <div class="col-sm-4 col-md-3 col-xs-12">
        <div class="footer-box">
          <h4>Information</h4>
          <ul class="list-unstyled">
            <li>
              <a href="terms-and-conditions.html">Terms and Conditions </a>
            </li>
            <li>
              <a href="privacy-policy.html">Privacy and Terms</a>
            </li>
            <li>
              <a href="#">Blog</a>
            </li>
            <li>
              <a href="contact-us.html">Contact Us </a>
            </li>
            <li>
              <a href="faq.html">FAQ</a>
            </li>
          </ul>
        </div>
      </div>
      <div class="col-sm-5 col-md-4 col-xs-12 small-dev">
        <div class="">
          <div class="footer-box newsletter">
            <h4>Newsletter</h4>
            <p>Subscribe to our newsletter for latest updates</p>
            <div class="input-group">
              <input type="text" class="form-control for_footer_width" placeholder="Enter your email address">
              <span class="input-group-addon">
                <img src="./assets/images/mail-sent-footer.png" alt="" />
              </span>
            </div>
            <ul class="list-inline">
              <li>
                <a href="#">
                  <i class="fa fa-facebook" aria-hidden="true"></i>
                </a>
              </li>
              <li>
                <a href="#">
                  <i class="fa fa-twitter" aria-hidden="true"></i>
                </a>
              </li>
              <li>
                <a href="#">
                  <i class="fa fa-google-plus" aria-hidden="true"></i>
                </a>
              </li>
              <li>
                <a href="#">
                  <i class="fa fa-instagram" aria-hidden="true"></i>
                </a>
              </li>
              <li>
                <a href="#">
                  <i class="fa fa-snapchat-ghost" aria-hidden="true"></i>
                </a>
              </li>
              <li>
                <a href="#">
                  <i class="fa fa-linkedin" aria-hidden="true"></i>
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
  $(function () {
    let location_path = window.location.href
    let location_file = location_path.split('/');
    let location_page = location_file[3].split('.');
    $('#KallableNavbar ul li').removeClass('active');
    setTimeout(function () {
      $('.navbar-nav li').find('a[href="' + location_page[0] + '.html"]').parent().addClass('active');
    }, 100)
  })

</script>



<!-- navbar end