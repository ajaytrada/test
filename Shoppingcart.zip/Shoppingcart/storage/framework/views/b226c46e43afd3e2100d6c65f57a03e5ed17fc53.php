
<div class="container">
 <div>
                      <form class="form-horizontal" method="POST" id="payment-form" role="form" action="<?php echo e(route('paypal1')); ?>" >

                        <?php echo e(csrf_field()); ?>


                        <div class="form-group<?php echo e($errors->has('amount') ? ' has-error' : ''); ?>">

                            <label for="amount" class="col-md-4 control-label">Amount</label>
                            <?php if(session()->has('success')): ?>
							<h3 class="alert alert-success"><?php echo e(session('success')); ?></h3>
							<?php endif; ?>

                            <div class="col-md-6">

                                <input id="amount" type="text" class="form-control" name="amount" value="<?php echo e(old('amount')); ?>" autofocus>

                                <?php if($errors->has('amount')): ?>

                                    <span class="help-block">

                                        <strong><?php echo e($errors->first('amount')); ?></strong>

                                    </span>

                                <?php endif; ?>

                            </div>

                        </div>

                        

                        <div class="form-group">

                            <div class="col-md-6 col-md-offset-4">

                                <button type="submit" class="btn btn-primary">

                                    Paywith Paypal

                                </button>

                            </div>

                        </div>

                    </form></div>

</div>

