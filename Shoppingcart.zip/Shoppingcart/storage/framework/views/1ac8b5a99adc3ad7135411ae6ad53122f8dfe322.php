<?php $__env->startSection('content'); ?>
<div class="container">
 <h2>Cart Items</h2>
 	<table class="table table-hover">
 	<?php echo e(csrf_field()); ?>

 		<thread>
 			<tr>
 			<th>id</th>
 			<th>name</th>
 			<th>price</th>
 			<th>quantity</th>
 			<th>total</th>
 			<th>tax</th>
 			<th>subtotal</th>
 			<th>update</th>
 			<th>remove</th>

 			
 			</tr>
 		</thread>
 		<tbody>
 		<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 		<tr>
 		<td><?php echo e($cartitem->id); ?></td>
 		<td><?php echo e($cartitem->name); ?></td>
 		<td><?php echo e($cartitem->price); ?></td>
 		<td><?php echo e($cartitem->qty); ?></td>
 		<td><?php echo e($cartitem->total); ?></td>
 		<td><?php echo e($cartitem->tax); ?></td>
 		<td><?php echo e($cartitem->subtotal); ?></td>
 		<td><button class="btn btn-info" id="updatecart"  value="<?php echo e($cartitem->id); ?>">update</button></td>
 		<td><button class="btn btn-danger" id="deletecart" value="<?php echo e($cartitem->id); ?>">remove</button></td>
 	
 		 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 	  
 	
 		</tr>
 		
 		</tbody>
 	</table>
  <a href="<?php echo e(route('checkout')); ?>" type='button' class="btn btn-primary" id="buy"    >Buy</a>
</form>

</div>
 <script src="<?php echo e(asset('/public/assets/js/jquery-3.2.1.min.js')); ?>"></script>
 <script src="<?php echo e(asset('/public/assets/bootstrap/bootstrap.min.js')); ?>"></script>
 <script src="<?php echo e(asset('/public/assets/custom_js/register_product.js')); ?>"></script>


<div class="modal fade" id="update_cart_Modal" 
     tabindex="-1" role="dialog" 
     aria-labelledby="favoritesModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" 
          data-dismiss="modal" 
          aria-label="Close">
          <span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" 
        id="favoritesModalLabel">Update cart</h4>
      </div>
     
      <div class="modal-body">
       <form class="form-horizontal" id="update_cartproduct">
         <?php echo e(csrf_field()); ?>

      		
      		  <input type="hidden" id="cart_product_id"  name="product_name" value="" >
      		
      		  <div class="col-sm-10">
      		     <label class="control-label col-sm-2" >ProductName</label>
                  <input type="text" class="form-control" id="cart_product_name"  name="product_name" value="" >
                  
            </div>
            <div class="col-sm-10">
	      		  <label class="control-label col-sm-2" >ProductPrice</label>
	      		  <input type="text" class="form-control" id="cart_product_price"  value="" name="product_price">
	      	 </div>
             <div class="col-sm-10">
             	   <label class="control-label col-sm-2" >ProductQuantity</label>
                  <input type="number" class="form-control product-quantity" id="cart_product_qty"  name="product_qty"  value="">
             </div>
            </form>
          </div>
        <div class="modal-footer">
      <!--   <button type="button" 
           class="btn btn-default" 
           data-dismiss="modal">Close</button> -->
        <span class="pull">
          <button type="submit" id="update_cart_item" class="btn btn-primary">
            Update Item
          </button>
        </span>
      </div>
    </div>
  </div>
</div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>