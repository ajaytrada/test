<?php $__env->startSection('content'); ?>

      <div class="wrapper">
         <form class="form-signin" method="post" action="">
            <?php echo e(csrf_field()); ?>

            <?php if(session('error')): ?>
            <h3 class="alert alert-danger"><?php echo e(session('error')); ?></h3>
            <?php endif; ?>
            <h2 class="form-signin-heading">Please login</h2>
            </br>
            <?php if($errors->has('email')): ?>
            <p><?php echo e($errors->first('email')); ?></p>
            <?php endif; ?>
            <?php if($errors->has('password')): ?>
            <p><?php echo e($errors->first('password')); ?></p>
            <?php endif; ?>
            <lable>Email</lable>
            <input type="email" class="form-control" name="email" /></br>
            <label>PASSWORD</label>
            <input type="password" class="form-control" name="password" />  <br>
            <label class="checkbox"></br>
            <input type="checkbox" value="remember-me" id="rememberMe" name="rememberme"> Remember me</br>
            </label>
            <button class="btn btn-lg btn-primary btn-block" type="submit">LOGIN</button>
            <button class="btn btn-lg btn-primary btn-block"><a href="reset" style="color:white">FORGOTPASSWORD</a></button>
         </form>
      </div>
     


  

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>