 $(document).ready(function()  {

$("#update_cart_Modal").modal('hide');
 	
   $(document).on('click','#cart', function(e){

    e.preventDefault();

   		var product_id = $(this).val();
      var csrf_token =$('input[name="_token"]').val();
       $.ajax({
                url:"http://mayuri.com/Shoppingcart/addCart",
                type: 'post',
                data: {'id':product_id,'_token':csrf_token},
                success: function (response) {
                      $(".cartcount").html(response);
                      $(".display").html("<p>view cart</p>");
                    }
             });
 	});


   $(document).on('click','#updatecart', function(e){

    e.preventDefault();

      var cart_id = $(this).val();
      alert(cart_id);
      var csrf_token =$('input[name="_token"]').val();
       $.ajax({
                url:"http://mayuri.com/Shoppingcart/updateCart",
                type: 'post',
                data: {'id':cart_id,'_token':csrf_token},
                success: function (response) {
                         $("#cart_product_id").val(JSON.parse(response).id);
                          $("#cart_product_name").val(JSON.parse(response).name);
                          $("#cart_product_price").val(JSON.parse(response).price);
                          $("#cart_product_qty").val(JSON.parse(response).qty);
                        
                       $("#update_cart_Modal").modal(response);

                    }
             });
  });

   $(document).on('click','#deletecart', function(e){
      e.preventDefault();
     
      var cart_id = $(this).val();
      
      var csrf_token =$('input[name="_token"]').val();
      var r = confirm(" You remove item from Cart Are You Sure?");
      if (r == true) 
      {
           $.ajax({
                    url:"http://mayuri.com/Shoppingcart/deleteCart",
                    type: 'post',
                    data: {'id':cart_id,'_token':csrf_token},
                    success: function (response) 
                    {
                        alert(JSON.stringify(response));
                      if(response=="success")
                      {
                        alert(response);
                        window.location.href="http://mayuri.com/Shoppingcart/showcart";
                      }
                      else
                      {
                        alert(response);
                      }
                    }
                 });
      }
      else
      {
        alert("You pressed Cancel!");
     }

  });

 	$('#addproduct').submit(function (e)
 	{
       e.preventDefault();
       var image=$("#file").prop('files')[0];
       var formdata =new FormData($("#addproduct")[0]);
       formdata.append('image',image); 
       $.ajax({
                url:"http://mayuri.com/Shoppingcart/addProduct",
               	type: 'post',
               	contentType: false,
                cache: false,
                processData: false,
                enctype:'multipart/formdata',
            		data: formdata,
            		success: function (response) {
              		alert(response);
                   	if(response=="Product submied")
                    {
                        location.href="http://mayuri.com/Shoppingcart/displayProduct";
                   	}
                   	else
                   	{
                       alert(response);
                   	}
                    }
                });

  	});



$('#showcart').click(function (e)
{
  alert("jiji");
  window.location.href="http://mayuri.com/Shoppingcart/showcart";
});

$('#update_cart_item').click(function (e)
{
   var id=$("#cart_product_id").val();
   var qty=$("#cart_product_qty").val();
   var name=$("#cart_product_name").val();
   var price=$("#cart_product_price").val();
  var csrf_token =$('input[name="_token"]').val();
   $.ajax({
                url:"http://mayuri.com/Shoppingcart/productupdateCart",
                type: 'post',
                data: {'id':id,'name':name,'qty':qty,'price':price,'_token':csrf_token},
                success:function(response)
                {
                   if(response="success")
                   {
                      window.location.href="http://mayuri.com/Shoppingcart/showcart";
                   }
                   else
                   {
                    alert(response);
                   }
                }
          });
});

});